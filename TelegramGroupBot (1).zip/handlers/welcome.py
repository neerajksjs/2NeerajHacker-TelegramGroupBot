async def welcome_new_member(client, message):
    for member in message.new_chat_members:
        await message.reply(f"Welcome {member.first_name}! Please follow the group rules.")
