import openai
from config import OPENAI_API_KEY

openai.api_key = OPENAI_API_KEY

async def handle_ai_reply(client, message):
    if message.text.startswith("/"):
        return

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "system", "content": "You are a helpful group assistant."},
                  {"role": "user", "content": message.text}]
    )

    reply_text = response['choices'][0]['message']['content']
    await message.reply(reply_text)
