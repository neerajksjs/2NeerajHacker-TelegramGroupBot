from pyrogram.types import Message
from pyrogram import Client, filters

async def handle_admin_command(client: Client, message: Message):
    chat_id = message.chat.id
    command = message.command[0].lower()
    if not message.reply_to_message:
        await message.reply("Reply to a user to use this command.")
        return

    user_id = message.reply_to_message.from_user.id

    if command == "ban":
        await client.ban_chat_member(chat_id, user_id)
        await message.reply("User banned.")
    elif command == "kick":
        await client.ban_chat_member(chat_id, user_id)
        await client.unban_chat_member(chat_id, user_id)
        await message.reply("User kicked.")
    elif command == "mute":
        await client.restrict_chat_member(chat_id, user_id, permissions=None)
        await message.reply("User muted.")
    elif command == "unmute":
        await client.restrict_chat_member(chat_id, user_id, permissions={"can_send_messages": True})
        await message.reply("User unmuted.")
    elif command == "promote":
        await client.promote_chat_member(chat_id, user_id, can_manage_chat=True, can_delete_messages=True, can_promote_members=False)
        await message.reply("User promoted.")
    elif command == "demote":
        await client.promote_chat_member(chat_id, user_id, can_manage_chat=False, can_delete_messages=False)
        await message.reply("User demoted.")
