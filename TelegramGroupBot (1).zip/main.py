from pyrogram import Client, filters
from config import API_ID, API_HASH, BOT_TOKEN
from handlers import commands, ai_reply, welcome

app = Client("GroupManagerBot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

@app.on_message(filters.new_chat_members)
async def welcome_handler(client, message):
    await welcome.welcome_new_member(client, message)

@app.on_message(filters.command(["ban", "kick", "mute", "unmute", "promote", "demote"]))
async def admin_commands(client, message):
    await commands.handle_admin_command(client, message)

@app.on_message(filters.text & filters.group)
async def ai_responder(client, message):
    await ai_reply.handle_ai_reply(client, message)

print("Bot is running...")
app.run()
